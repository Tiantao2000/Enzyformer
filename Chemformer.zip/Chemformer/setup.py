from setuptools import setup, find_packages

setup(name="molbart", packages=find_packages())
